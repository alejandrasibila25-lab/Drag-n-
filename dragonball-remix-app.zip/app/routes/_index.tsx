import Navbar from "~/components/Navbar";
import Hero from "~/components/Hero";
import Story from "~/components/Story";
import Characters from "~/components/Characters";
import Footer from "~/components/Footer";

export default function Index() {
  return (
    <main className="overflow-x-hidden">
      <Navbar />
      <Hero />
      <Story />
      <Characters />
      <Footer />
    </main>
  );
}
