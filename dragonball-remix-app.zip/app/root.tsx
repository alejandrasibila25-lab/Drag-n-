import { Links, Meta, Outlet, Scripts, ScrollRestoration } from "@remix-run/react";
import styles from "./styles/tailwind.css";

export const links = () => [{ rel: "stylesheet", href: styles }];

export default function App() {
  return (
    <html lang="es">
      <head>
        <Meta />
        <Links />
        <title>Dragon Ball — El legado Saiyajin</title>
      </head>
      <body className="bg-neutral-950 text-white">
        <Outlet />
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  );
}
