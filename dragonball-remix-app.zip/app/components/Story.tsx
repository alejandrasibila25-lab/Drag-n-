export default function Story() {
  return (
    <section className="py-32 px-6 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-6">El paso del tiempo</h2>
      <p className="text-gray-400 leading-relaxed">
        Las batallas terminan, pero los recuerdos permanecen. El universo sigue evolucionando.
      </p>
    </section>
  );
}
