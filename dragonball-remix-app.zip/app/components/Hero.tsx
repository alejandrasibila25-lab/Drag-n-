import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="h-screen flex items-center justify-center text-center px-6">
      <div>
        <motion.h1 initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} className="text-6xl font-extrabold">
          Incluso después de la batalla…<br />el poder sigue creciendo
        </motion.h1>

        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6 text-gray-400 max-w-xl mx-auto">
          Cada enemigo es solo el inicio de una nueva transformación.
        </motion.p>
      </div>
    </section>
  );
}
