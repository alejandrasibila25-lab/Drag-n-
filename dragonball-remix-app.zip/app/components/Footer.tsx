export default function Footer() {
  return (
    <footer className="py-10 text-center text-gray-500 text-sm">
      El poder nunca desaparece, solo evoluciona.
    </footer>
  );
}
