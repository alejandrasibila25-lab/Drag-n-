const warriors = [
  { name: "Goku", desc: "Siempre supera sus límites" },
  { name: "Vegeta", desc: "Orgullo Saiyajin" },
  { name: "Gohan", desc: "Poder oculto" },
  { name: "Trunks", desc: "El futuro" }
];

export default function Characters() {
  return (
    <section className="py-32 px-6">
      <h2 className="text-center text-3xl font-bold mb-16">Guerreros</h2>
      <div className="grid md:grid-cols-4 gap-8 max-w-6xl mx-auto">
        {warriors.map((w, i) => (
          <div key={i} className="p-6 border border-white/10 rounded-xl bg-white/5">
            <h3 className="text-xl mb-2">{w.name}</h3>
            <p className="text-sm text-gray-400">{w.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
