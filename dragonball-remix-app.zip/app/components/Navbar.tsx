export default function Navbar() {
  return (
    <header className="fixed top-0 w-full z-50 backdrop-blur bg-black/40 border-b border-white/10">
      <nav className="max-w-6xl mx-auto flex justify-between items-center p-5">
        <h1 className="font-bold tracking-widest text-orange-400">DRAGON BALL</h1>
        <ul className="flex gap-8 text-sm text-gray-300">
          <li>Historia</li>
          <li>Guerreros</li>
          <li>Legado</li>
        </ul>
      </nav>
    </header>
  );
}
